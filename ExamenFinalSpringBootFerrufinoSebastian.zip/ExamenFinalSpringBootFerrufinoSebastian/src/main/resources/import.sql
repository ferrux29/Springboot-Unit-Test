INSERT INTO Clientes(nombre) VALUES ('Sebastian');
INSERT INTO Clientes(nombre) VALUES ('Ferrufino');
INSERT INTO Pedidos(codigo_pedido, cantidad_productos) VALUES ('Pedido01', 3000);
INSERT INTO Pedidos(codigo_pedido, cantidad_productos) VALUES ('Pedido02', 15);
